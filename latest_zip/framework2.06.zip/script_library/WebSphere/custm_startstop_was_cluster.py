#![.py]/bin/sh -c "$WAS_HOME/bin/wsadmin.sh -user $WAS_ADMIN_USER -password $WAS_ADMIN_PASSWORD -lang jython -f %%"

# Executes start or stop cluster or server, used when connecting to a Deployment Manager or NodeAgent
# Jython script below is passed to the wsadmin command from line 1
#
# Requires the following variables to be set
#    WAS_HOME		#path to /bin/wsadmin.sh
#    WAS_ADMIN_USER   #wsadmin username
#    WAS_ADMIN_PASSWORD  #wsadmin password
#    WAS_Action    #stop, start
#    WAS_ClusterName	
#	 WAS_SleepTime		#sleep time between checks
#	 WAS_NumChecks		#number of checks to perform if cluster is up or down

import os
import org.python.modules
import time
from sys import argv
from java.util import Properties

def checkServers ( startOrStop, clusterName ):

	global AdminControl
	global AdminConfig
	global AdminApp

	# check all the apps and servers in the cell to see if they are running
	cell = AdminConfig.list("Cell" )
	cellName = AdminControl.getCell( )
	clusters = AdminConfig.list("ServerCluster", cell )

	# print "Finding Cluster in Cell: " + cellName
	clusterMgr = AdminControl.completeObjectName('cell=' + cellName+ ',type=ClusterMgr,*')
	# print "Using Cluster Manager: " + clusterMgr
	for aCluster in clusters.split():
		cName = AdminConfig.showAttribute(aCluster, "name" )
		if (clusterName == cName):
			print "Located Cluster: " + cName
			clusterObj = AdminControl.completeObjectName('cell=' + cellName + ',type=Cluster,name=' + cName + ',*')

			if ( startOrStop == "start" ):
				print "Starting Cluster Members"
				AdminControl.invoke(clusterObj, startOrStop)
			elif ( startOrStop == "stop" ):
				print "Stopping Cluster Members"
				AdminControl.invoke(clusterObj, startOrStop)
			#endIf
			checkClusterStatus( clusterObj, startOrStop )
		#EndIf
	#endFor
#endDef

def checkClusterStatus ( clusterObj, startOrStop ):
	status = "blank"
	stateCheck = ""
	if( startOrStop == "start"):
		stateCheck = "websphere.cluster.running"
	if( startOrStop == "stop"):
		stateCheck = "websphere.cluster.stopped"
	checks = 0
	while ( checks < int( numChecks ) and status != stateCheck ):
		print "%s" % time.ctime()
		status =  AdminControl.getAttribute(clusterObj, "state" )
		print "Cluster State: " + status;
		checks += 1
		time.sleep(int( sleepTime ))
	#endWhile
#endDef

startOrStop = os.environ["WAS_Action"]
clusterName = os.environ["WAS_ClusterName"]
sleepTime = os.environ["WAS_SleepTime"]
numChecks = os.environ["WAS_NumChecks"]
	
if( startOrStop == "start"):
	checkServers(startOrStop, clusterName )
if( startOrStop == "stop"):
	checkServers(startOrStop, clusterName )
if( startOrStop == "restart"):
	checkServers("stop", clusterName )
	checkServers("start", clusterName )
#endIf


