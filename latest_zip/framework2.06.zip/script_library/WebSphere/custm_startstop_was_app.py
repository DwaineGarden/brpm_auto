#![.py]/bin/sh -c "$WAS_HOME/bin/wsadmin.sh -user $WAS_ADMIN_USER -password $WAS_ADMIN_PASSWORD -lang jython -f %%"

# Executes start or stop Application on specified scope, used when connecting to a Deployment Manager or NodeAgent
# Jython script below is passed to the wsadmin command from line 1
#
# Requires the following variables to be set
#    WAS_HOME		#path to /bin/wsadmin.sh
#    WAS_ADMIN_USER   #wsadmin username
#    WAS_ADMIN_PASSWORD  #wsadmin password
#    WAS_Action    #stop, start
#    WAS_AppName	# comma separated list of AppNames
#	 WAS_Scope		#cluster, server, cell
#    WAS_ClusterName	
#Optional:
#    WAS_ServerName
#    WAS_NodeName
		
import os		
import string	
		
startOrStop = os.environ["WAS_Action"]
appNames = os.environ["WAS_AppName"]
scope = os.environ["WAS_Scope"]
appList = appNames.split(',')

def getAppStatus(appName):
    # If objectName is blank, then the application is not running.
    objectName = AdminControl.completeObjectName("type=Application,name="+appName+",*")
    if objectName == "":
        appStatus = 'Stopped'
    else:
        appStatus = 'Running'
    return appStatus

def appStatusInfo():
    appsString = AdminApp.list()
    appList = string.split(appsString, '\r\n')

    print '============================'
    print ' Status |    Application   '
    print '============================'

    # Print apps and their status
    for x in appList:
		if " " in x:   #THIS IS NOT WORKING AS EXPECTED
			print "Cannot check applications with spaces: " + app
		else:
			print getAppStatus(x) + ' | ' + x

    print '============================'



for app in appList:
	if (scope == "cluster"):
		clusterName = os.environ["WAS_ClusterName"]
		if (startOrStop == "start"):
			appStatus = getAppStatus(app)
			if (appStatus == 'Running'):
				print "Application " + app + "is already running"
			else:	
				print "Attempting start of " + app
				AdminApplication.startApplicationOnCluster(app, clusterName)
		else:
			appStatus = getAppStatus(app)
			if (appStatus == 'Stopped'):
				print "Application " + app + "is already stopped"
			else:
				print "Attempting stop of " + app
				AdminApplication.stopApplicationOnCluster(app, clusterName)
	elif (scope == "server"):
		serverName = os.environ["WAS_ServerName"]
		nodeName = os.environ["WAS_NodeName"]
		if (startOrStop == "start"):
			print "Attempting start of " + app
			AdminApplication.startApplicationOnSingleServer(app, nodeName, serverName)
		else:
			print "Attempting stop of " + app		
			AdminApplication.stopApplicationOnSingleServer(app, nodeName, serverName)
	elif (scope == "cell"):
		# scope is cell # NOT TESTED
		for appName in appNames.split(","):
			WasDeploy.startStopAppOnModuleMappedServers(appName, startOrStop)
		#endFor
	else:
		print "Error: Unknown scope supplied."
#endIf

#appStatusInfo()