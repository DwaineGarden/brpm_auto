################################################################################
# BMC Software, Inc.
# Confidential and Proprietary
# Copyright (c) BMC Software, Inc. 2001-2014
# All Rights Reserved.
################################################################################
#---------------------- util_f2_installModule -----------------------#
# Description: Installs automations into BRPM
#=> About the f2 framework: upon loading the automation, several utility classes will be available
#   @rpm: the BrpmAutomation class, @p: the Param class, @rest: the BrpmRest class and 
#   @transport: the Transport class - the transport class will be loaded dependent on the SS_transport property value (ssh, nsh or baa) 
require "#{FRAMEWORK_DIR}/brpm_framework.rb"
#
#---------------------- Arguments --------------------------#
###
# Select Modules:
#   name: Module picker
#   position: A1:F1
#   type: in-external-multi-select
#   external_resource: util_f2_rsc_moduleTree
# output_status:
#   name: status
#   type: out-text
#   position: A1:F1
###

#---------------------- Declarations -----------------------#

#---------------------- Methods ----------------------------#
def file_content(path)
  cont
  File.open(path) do |fil|
    cont = fil.read
  end
  cont
end

def create_automation(script_path)
  body = file_content(script_path)
  @rpm.log "\tInstall: #{script_path}"
  script_name = File.basename(script_path).gsub(".rb", "")
  d_match = body.match(/\#\sDescription:\s.*/)
  description = d_match.nil? ? "imported f2 module" : d_match.to_s.gsub("# Description: ", "").chomp
  automation_type = script_name.include?("_rsc") ? "ResourceAutomation" : "Automation"
  rest_params = {"name" => script_name, "description" => description, "content" => body, "automation_category" => automation_category, "automation_type" => automation_type}
  result = @rest.create("scripts", rest_params)
  if result["status"].start_with?("ERROR")
    @rpm.log result 
    raise "Error Creating Script"
  end
  cur_id = result["data"]["id"]
  result @rest.update("scripts", cur_id, {"script" => {"aasm_state" => "pending"}})
  result @rest.update("scripts", cur_id, {"script" => {"aasm_state" => "released"}})
end

#---------------------- Variables --------------------------#
params["direct_execute"] = true
selected_modules = @p.get("Select Modules")
@modules_base_path = File.join(FRAMEWORK_DIR,"..","automation")
automation_category = "Framework"

#---------------------- Main Body --------------------------#
if selected_modules.include?("|")
  modules_to_install = []
  selected_modules.split(",").each do |item|
    selected_module = File.join(item.split("|")[1], item.split("|")[0])
    selected_module = File.join(@modules_base_path, selected_module) unless selected_module.include?(@modules_base_path)
    modules_to_install << selected_module
  end
end
raise "Command_Failed: No script to execute: #{selected_modules}" if selected_modules == "" || !File.exist?(selected_modules)
script = File.open(selected_modules).read
@rpm.message_box "Installing Modules"
@rpm.log "Selected: #{modules_to_install.join(",")}"
modules_to_install.each do |module_path|
  @rpm.log "Module: #{File.basename(module_path)}"
  Dir.entries(module_path).reject{|k| k.start_with?(".")}.each do |script|
    create_automation(File.join(module_path, script)) if script.include?("_rsc")
  end
  Dir.entries(module_path).reject{|k| k.start_with?(".")}.each do |script|
    create_automation(File.join(module_path, script)) if !script.include?("_rsc")
  end
end
  
exit_status = "Success"
result.split("\n").each{|line| exit_status = line if line.start_with?("EXIT_CODE:") }
pack_response("output_status", exit_status)




