#-------------  f2_dispatchFilePut -------------------------#
# This dispatcher will be invoked to execute a Remote file put via nsh.
# The server list passed to this script will all have the source files
# copied to the target path relative to SS_CHANNEL_ROOT

#---------------------- Arguments --------------------------#
###
# source host:
#   name: Source Hostname (default = localhost)
#   type: in-text
#   position: A1:C1
# source path:
#   name: Source Path (default is version_tag)
#   type: in-text
#   position: A2:F2
# target path:
#   name: Target Path (Relative to CHANNEL_ROOT)
#   type: in-text
#   position: A3:F3
###

#---------------------- Declarations -----------------------#
#=> Load Base Framework modules
require "#{FRAMEWORK_DIR}/lib/brpm_automation"
require "#{FRAMEWORK_DIR}/lib/param"
@p = Param.new(params)

#---------------------- Methods ----------------------------#
def params_to_env(params)
  params.each do |name, value|
    val = value.gsub("\n","_CR_").gsub("\r\n", "_CR_")
    ENV[name] = val
  end
end
    
#---------------------- Variables --------------------------#
@DEFAULT_CHANNEL_ROOT = '/tmp'
@WINDOWS_CHANNEL_ROOT = '/C/windows/temp'
@NUM_THREADS = 10 # degree of parallelism for this dispatcher
@NSH_OPTIONS = {
    nsh_path: '', # set to NSH dir path if nsh commands are not in PATH
    nshrunner: false, # set to true if you want to use nshrunner
    verbose: true,
    test_mode: false
}

@target_path_key = 'target path'
@source_path_key = 'source path'
@source_host_key = 'source host'
target_path = @p.get(@target_path_key)

if @p.get(@source_path_key) == ""
  if @p.step_version_artifact_url == ""
    puts_stderr 'Source path not specified'
    exit 1
  else
    @p.add(@source_path_key, @p.step_version_artifact_url)
  end
end
@file_name = File.basename(source_path)

if target_path == ""
  puts_stdout 'Target path not specified, assuming SS_CHANNEL_ROOT'
  @p.add(@target_path_key, '.')
else
  @p.add(@target_path_key, File.join(target_path, @file_name)) if File.extname(target_path) == ""
end

if @p.get(@source_host_key) == ""
  puts_stdout 'Source host not specified, assuming localhost'
  @p.add(@source_host_key, 'localhost')
end
  
#---------------------- Main Body --------------------------#
@rpm.message_box "Dispatch File Put for NSH\n"
@rpm.log "Copying //#{@p.get(@source_host_key)}#{@p.get(@source_path_key)} to SS_CHANNEL_ROOT/#{target_path}"
@rpm.log "On the following hosts: #{get_selected_hosts.inspect}\n"

@nsh_run = NshDispatchScript.new(@p.params, @NSH_OPTIONS)


if @nsh_run.bulk_copy?
  bulk_remote_path = ''
  server_list = []
  first_server_props = nil
  get_server_list(params).each do |server, props|
    first_server_props ||= props
    server_params = params.merge(props)
    params_to_env(server_params)
    target_path = get_target_path(server_params)
    if bulk_remote_path.empty? && !target_path.nil?
      # Get the first available target_path and use for remote path
      bulk_remote_path = "#{target_path}/#{params[@target_path_key]}".gsub(/\/\/*/,'/')
    end
    server_list << server_addr(server, props)
  end

  @nsh_run.log_tag_list = server_list
  @nsh_run.set_nsh_blcred(first_server_props)
  @nsh_run.ncp(server_list,"//#{params[@source_host_key]}/#{params[@source_path_key].gsub(/^\//,'')}", bulk_remote_path, @NUM_THREADS.to_i > 0 ? @NUM_THREADS.to_i : 1)
else
  get_server_list(params).each do |server, props|
    @nsh_run.log_tag_list = [server_addr(server, props)]
    @nsh_run.set_nsh_blcred(props)
    server_params = params.merge(props)
    params_to_env(server_params)
    target_path = get_target_path(server_params)
    remote_path = File.join(target_path, @p.get(@target_path_key)).gsub(/\/\/*/,'/')
    @nsh_run.ncp([server_addr(server, props)], File.join("//#{@p.get(@source_host_key)}",@p.get(@source_path_key)), remote_path)
  end
end
