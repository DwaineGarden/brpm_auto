#---------------------- Rally: Get Tickets -----------------------#
#    Queries for Tickets in Rally
###
# Ticket Type:
#   name: Type of rally item 
#   position: A1:C1
#   type: in-list-single
#   list_pairs: defect,Defect|story,User Story
#   required: yes
# Rally Project:
#   name: Choose a rally project
#   position: A2:C2
#   type: in-text
#   required: yes
# Rally Iteration:
#   name: Choose an iteration
#   position: A3:D3
#   type: in-external-single-select
#   external_resource: rsc_rallyIterations
#   required: no
# Schedule State:
#   name: Schedule state 
#   position: A4:D4
#   type: in-list-single
#   list_pairs: Backlog,Backlog|Defined,Defined|InProgress,InProgress|Completed,Completed|Accepted,Accepted|Release,Release
# Ticket State:
#   name: State of Ticket (submitted, open, resolved, complete, etc)
#   position: A5:D5
#   type: in-text
#   required: no
###
#---------------------- Integration Header (do not modify) -----------------------#


#=== Rally Integration Server: BMC Rally ===#
# [integration_id=7]
SS_integration_dns = "https://rally1.rallydev.com/slm"
SS_integration_username = "bbyrd@bmc.com"
SS_integration_password = "-private-"
SS_integration_details = "api_version: v2.0
workspace: ESM
project: RPM Sustaining"
SS_integration_password_enc = "__SS__Cj1VV2IwVTJib0ZHVg=="
#=== End ===#


SS_integration_id = 6


#---------------------- Declarations -----------------------#
# Flag the script for direct execution
require 'uri'
params["direct_execute"] = true


#---------------------- Methods -----------------------#
def get_param(params,key)
  res = params[key] if params.has_key?(key)
  res ||= ""
end
  
def message_box(txt, style)
  puts txt
end

def rest_call(url, method, options = {})
  methods = %w{get post put}
  result = rest_params = {}
  rest_params[:url] = url
  unless methods.include?(method.downcase)
    write_to "No method named: #{method}"
    result["status"] = "failure"
    result["message"] = "No method named: #{method}"
    return result
  end
  rest_params[:method] = method.downcase
  begin
    message_box("REST call", "title") unless options.has_key?("quiet")
    write_to "\tFetching url: #{method} #{url}"
    if options.has_key?("username") && options.has_key?("password")
      rest_params[:user] = options["username"]
      rest_params[:password] = options["password"]
    end
    if %{put post}.include?(method.downcase)
      rest_params[:payload] = options["data"].to_json if options.has_key?("data")
      rest_params[:payload] = options.to_json if options.is_a?(String) # Old method post
      if !options.has_key?("data") || rest_params[:payload].length < 4
        result["status"] = "failure"
        result["message"] = "No Post data"
        return result
      end
      write_to "\tPost Data: #{rest_params[:payload].inspect}" unless options.has_key?("quiet")
    end
    rest_params.merge!({:headers => { :accept => :json, :content_type => :json }}) unless rest_params.has_key?(:headers)
    write_to rest_params.inspect if options.has_key?("verbose")
    response = RestClient::Request.new(rest_params).execute
    if response.code < 300
      write_to "\treturn code: #{response.code}"
      write_to "\tParsing response to JSON format ..."
      parsed_response = JSON.parse(response)
      result["code"] = response.code
      write_to "Parsed response: #{parsed_response.inspect}" if options.has_key?("verbose")
      result["status"] = "success"
      result["response"] = parsed_response
    else
      result["status"] = "failure"
      result["response"] = response
      write_to "\tError: REST call returned HTTP code #{response.code}"
    end
  rescue Exception => e
    result["status"] = "failure"
    result["message"] = e.message
    write_to "\tError: REST call generated an error: #{e.message}\n#{e.backtrace}"
  end
  result
end

def log_it(it)
  log_path = File.join(@params["SS_automation_results_dir"], "resource_logs")
  txt = it.is_a?(String) ? it : it.inspect
  write_to txt
  Dir.mkdir(log_path) unless File.exist?(log_path)
  s_handle = defined?(@script_name_handle) ? @script_name_handle : "rally_ticket"
  fil = File.open("#{log_path}/#{s_handle}_#{@params["SS_run_key"]}", "a")
  fil.puts txt
  fil.flush
  fil.close
end


def build_query(query_hash)
  #query=(((Project.name = "BMC Release Process Management") and (Iteration.Name = "RPM iteration 28")) and (ScheduleState = "In-Progress"))
  #query=((Project.name = "BMC Release Process Management") and (ScheduleState = "In-Progress"))
  res = ""
  first = true
  query_hash.each do |k,v|
    res += "(#{k} = \"#{v}\")" if first
    res += " and (#{k} = \"#{v}\")" unless first
    first = false
  end
  query_hash.size > 1 ? "(#{res})" : res
end

def ticket_summary(tickets)
  write_to "Tickets Summary"
  write_to "ID -----".ljust(10) + "-- Name ---------------------------".ljust(36) + "Priority ---".ljust(15) + "Owner ----".ljust(15) + "State ---"
  tickets.each do |item|
    out = "#{rally_field(item, "FormattedID").ljust(8)}| "
    out += "#{rally_field(item, "Name")[0..32].ljust(33)}| "
    #out += "#{rally_field(item, "Severity").ljust(14)}| "
    out += "#{rally_field(item, "Priority").ljust(14)}| "
    out += "#{rally_field(item, "Owner")}| "
    out += "#{rally_field(item, "State")}"
    write_to out
  end
end

def rally_field(ticket, field)
  trap_fields = %w{Owner SubmittedBy}
  ans = ""
  val = ticket[field]
  return ans if val.nil?
  if trap_fields.include?(field)
    ans = val["_refObjectName"] if val.has_key?("_refObjectName")
  else
    unless val.is_a?(String)
      if val.respond_to?("to_s")
        ans = val.to_s
      else
        ans = val.inspect 
      end
    else
      ans = val
    end
  end
  return ans || ""
end

def format_tickets(tickets, ticket_type)
  results = []
  tickets.each do |item|
		ticket = {}
		ticket["foreign_id"] = rally_field(item, "FormattedID")
		ticket["name"] = rally_field(item, "Name")
		ticket["status"] = ticket_type == "Defect" ? rally_field(item, "State") : rally_field(item, "ScheduleState")
		ticket["project_server_id"] = SS_integration_id
		ticket["ticket_type"] = ticket_type 
		ticket["url"] = rally_field(item, "_ref")
		ticket["extended_attributes"] = rally_field(item, "Owner") + rally_field(item, "Severity") + rally_field(item, "Priority") if ticket_type == "Defect"
		ticket["extended_attributes"] = rally_field(item, "Owner") + rally_field(item, "Priority") unless ticket_type == "Defect"
    results << ticket
	end
  results
end

#---------------------- Variables -----------------------#
# Assign local variables to properties and script arguments

#---------------------- Main Body -----------------------#
# Call REST Interface in Rally
def execute(script_params, parent_id, offset, max_records)
  details = YAML.load(SS_integration_details)
  int_password = decrypt_string_with_prefix(SS_integration_password_enc)
  base_url = "#{SS_integration_dns}/slm/webservice/#{details["api_version"]}/"
  log_it(script_params)
  ticket_type = get_param(script_params,"Ticket Type")
  obj_type = ticket_type == "Defect" ? "defect.js" : "hierarchicalrequirement.js"
  project = get_param(script_params,"Rally Project")
  iteration = get_param(script_params,"Rally Iteration")
  ticket_state = get_param(script_params,"Ticket State")
  schedule_state = get_param(script_params,"Schedule State")
  #query_string = "(((State = \"Open\") or (State = \"Submitted\")) and (Project.Name = \"#{project}\"))"
  #query_string = "State = \"Submitted\", Severity <= \"4 - Low\", Project.Name = \"#{project}\""
  query_hsh = {"Project.Name" => project}
  query_hsh["Iteration.Name"] = iteration if iteration.length > 2 #and ticket_type != "Defect"
  query_hsh["TicketState"] = ticket_state if ticket_state.length > 2 #and ticket_type != "Defect"
  query_hsh["ScheduleState"] = schedule_state if schedule_state.length > 2 #and ticket_type != "Defect"
  query_hsh["State"] = ticket_state if ticket_state.length > 2 and ticket_type == "Defect"
  query = "query=#{build_query(query_hsh)}"
  sort = "order=Name asc"
  tail = "pagesize=200&fetch=true"
  full_url = base_url + obj_type + "?" + query + "&" + sort + "&" + tail
  log_it(full_url)
  clean_url = URI.escape(full_url)
  rest_params = {:headers => { :accept => :json}, "username" => SS_integration_username, "password" => int_password, "verbose" => "yes"}
  response = rest_call(clean_url, "get", rest_params)
  total_count = response["response"]["QueryResult"]["TotalResultCount"]
  write_to "Querying Rally"
  write_to "=> criteria: #{query}"
  write_to "=> result: Found #{total_count} #{ticket_type.downcase}"
  log_it(response["response"]["QueryResult"]["Results"])
  #ticket_summary(response["response"]["QueryResult"]["Results"])
  tickets = format_tickets(response["response"]["QueryResult"]["Results"],ticket_type)
  
  ############################ TICKET MAPPING AREA -- REQUIRED FOR MAPS_TO TICKET RESOURCE AUTOMATON 

  # we are going to expect an array here that fits the table control standard AND that can be mapped
  # to our ticket and extended attributes tabs.  For example, we must return an initial header element
  # and then data to match.  The unique id for the first column will not be shown on the table and 
  # is user to store selected values by check box on the table control. The foreign_id in the 2nd column
  # is often but not necessarily the same value as the ra_uniq_identifier since it is usually guaranteed to 
  # be unique by the remote ticketing system. 
  results = []
  # add the mandatory header row
  results << ["ra_uniq_identifier","Foreign Id","Name","Ticket Type", "Status", "Extended Attributes"]
  # now loop through the results and prepare a hash that fits the maps_to Ticket requirements
  unless tickets.empty?
    tickets.each_with_index do |ticket, index|
      #initialize a row array, not a hash, compatible with tickets and the table control
      #note: order is essential here as these are not key value pairs, must match header order
      t_row = []
      # find and set the unique identifier for this row -- string or integer
      # might be ok to put in the row index if this is blank or non-unique
      t_row << ticket["foreign_id"] || index
      # now set the ticket mapping fields required to turn this into a ticket model
      t_row <<  ticket["foreign_id"] || "Foreign ID Missing: Using #{Time.now.to_s}"
      t_row << (ticket["name"] || "Name Unavailable")[0..255]
      t_row << ticket["ticket_type"]
      t_row << (ticket["status"] || "Status Unavailable")[0..255]
      t_row << (ticket["url"] || "")[0..255]
      t_row << {"description" => ticket["extended_attributes"]}.to_json
      results << t_row
    end
  else
    # return just the headers and no subsequent values and rely on the control to say nothing was returned
  end


  # TODO: The AO adapter was not originally enabled to return total matching records and paginated results
  # so we are setting these values to the length of the returned records for compatibility
  paginated_results = { :perPage => tickets.length, 
                        :totalItems => tickets.length, 
                        :data => results }

  ############################ END TICKET MAPPING AREA #############################################

  # write the ticket data to the output file for record keeping and debugging
  fil = File.open(script_params["SS_output_file"],"a")
  
  fil.puts("#=== TICKET DATA ===#")
  fil.puts(paginated_results.to_yaml)
  fil.puts("#=== END TICKET DATA ===#")
  fil.flush
  fil.close
  return paginated_results
end

def import_script_parameters
  { "render_as" => "Ticket" }
end
