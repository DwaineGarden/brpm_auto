###
# Rally Project:
#   name: Choose a rally project
#   position: A2:C2
#   type: in-text
#   required: yes
###
#---------------------- Integration Header (do not modify) -----------------------#


#=== Rally Integration Server: BMC Rally ===#
# [integration_id=7]
SS_integration_dns = "https://rally1.rallydev.com/slm"
SS_integration_username = "bbyrd@bmc.com"
SS_integration_password = "-private-"
SS_integration_details = ""
SS_integration_password_enc = "__SS__Cj1VV2IwVTJib0ZHVg=="
#=== End ===#


SS_integration_id = 6

#---------------------- Declarations -----------------------#
# Flag the script for direct execution
require 'uri'
params["direct_execute"] = true

#---------------------- Methods -----------------------#
def get_param(params,key)
  res = params[key] if params.has_key?(key)
  res ||= ""
end

def message_box(txt, style)
  puts txt
end

def rest_call(url, method, options = {})
  methods = %w{get post put}
  result = rest_params = {}
  options["verbose"] = "yes"
  rest_params[:url] = url
  unless methods.include?(method.downcase)
    log_it "No method named: #{method}"
    result["status"] = "failure"
    result["message"] = "No method named: #{method}"
    return result
  end
  rest_params[:method] = method.downcase
  begin
    log_it("REST call") unless options.has_key?("quiet")
    log_it "\tFetching url: #{method} #{url}"
    if options.has_key?("username") && options.has_key?("password")
      rest_params[:user] = options["username"]
      rest_params[:password] = options["password"]
    end
    if %{put post}.include?(method.downcase)
      rest_params[:payload] = options["data"].to_json if options.has_key?("data")
      rest_params[:payload] = options.to_json if options.is_a?(String) # Old method post
      if !options.has_key?("data") || rest_params[:payload].length < 4
        result["status"] = "failure"
        result["message"] = "No Post data"
        return result
      end
      write_to "\tPost Data: #{rest_params[:payload].inspect}" unless options.has_key?("quiet")
    end
    rest_params.merge!({:headers => { :accept => :json, :content_type => :json }}) unless rest_params.has_key?(:headers)
    log_it rest_params.inspect if options.has_key?("verbose")
    response = RestClient::Request.new(rest_params).execute
    if response.code < 300
      log_it "\treturn code: #{response.code}"
      log_it "\tParsing response to JSON format ..."
      parsed_response = JSON.parse(response)
      result["code"] = response.code
      log_it "Parsed response: #{parsed_response.inspect}" if options.has_key?("verbose")
      result["status"] = "success"
      result["response"] = parsed_response
    else
      result["status"] = "failure"
      result["response"] = response
      log_it "\tError: REST call returned HTTP code #{response.code}"
    end
  rescue Exception => e
    result["status"] = "failure"
    result["message"] = e.message
    write_to "\tError: REST call generated an error: #{e.message}\n#{e.backtrace}"
  end
  result
end

def log_it(it)
  log_path = File.join(@params["SS_automation_results_dir"], "resource_logs")
  txt = it.is_a?(String) ? it : it.inspect
  write_to txt
  Dir.mkdir(log_path) unless File.exist?(log_path)
  s_handle = defined?(@script_name_handle) ? @script_name_handle : "rally_iterations"
  fil = File.open("#{log_path}/#{s_handle}_#{@params["SS_run_key"]}", "a")
  fil.puts txt
  fil.flush
  fil.close
end


def hashify_list(list)
  response = {}
  list.each_with_index do |item,idx| 
    response[item["_refObjectName"]] = item["_refObjectName"] #item["_ref"]
  end
  return [response]
end

#---------------------- Main Routine ----------------------------#
def execute(script_params, parent_id, offset, max_records)
  #  Get iterations in the context of a project
  # https://rally1.rallydev.com/slm/webservice/1.40/iteration.js?query=project=https://rally1.rallydev.com/slm/webservice/1.40/project/3862856604.js&pagesize=200&fetch=true
  details = YAML.load(SS_integration_details)
  int_password = decrypt_string_with_prefix(SS_integration_password_enc)
  base_url = "#{SS_integration_dns}/slm/webservice/#{details["api_version"]}/"
  object_type = "iteration.js"
  begin
    project = script_params["Rally Project"]
    ticket_type = script_params["Ticket Type"]
    if true #project.include?("http")
      log_it "Project: #{project}, type: #{ticket_type}\nParams: #{script_params.inspect}"
      query = "query=(Project.Name = \"#{project}\")"
      tail = "pagesize=200&fetch=true"
      full_url = base_url + object_type + "?" + query + "&" + tail
      clean_url = URI.escape(full_url)
      rest_params = {:headers => { :accept => :json}, "username" => SS_integration_username, "password" => int_password, "verbose" => true }
      response = rest_call(clean_url, "get", rest_params)
      log_it "RestResponse: #{response.inspect}"
      total_count = response["response"]["QueryResult"]["TotalResultCount"]
      log_it "Querying Rally"
      log_it "=> criteria: #{query}"
      log_it "=> result: Found #{total_count} items"
      # Now list the Iterations
      log_it "#------------- #{object_type} params ----------------#\n"
      response["response"]["QueryResult"]["Results"].first.each{ |k,v| write_to("#{k} => #{v.inspect}") }
      log_it "#------------- #{object_type} ----------------#\n"
      response["response"]["QueryResult"]["Results"].each{ |it| write_to("#{it["_refObjectName"]}: #{it["_ref"]}" ) }
      result = hashify_list(response["response"]["QueryResult"]["Results"])
    else
      result = [{"Select" => "Select a Project"}]
    end
    select_hash = {}
    select_hash["Select"] = ""
    result.unshift(select_hash)
    log_it result.inspect
  rescue Exception => e
    log_it "#{e.message}\n#{e.backtrace}"
  end

  log_it(result)
  return result  
end

def import_script_parameters
  { "render_as" => "List" }
end

