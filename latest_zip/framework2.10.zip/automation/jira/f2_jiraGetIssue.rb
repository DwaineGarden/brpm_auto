#---------------------- f2_jira_updateStatus -----------------------#
# Description: Updates the status of a Jira issue
#=> About the f2 framework: upon loading the automation, several utility classes will be available
#   @rpm: the BrpmAutomation class, @p: the Param class, @rest: the BrpmRest class and 

#---------------------- Arguments --------------------------#
###
# issue_id:
#   name: id of jira issue (leave blank to use attached issues)
#   position: A1:F1
#   type: in-text
# desired_state:
#   name: State of issue to proceed
#   position: A2:C2
#   type: in-text
###


#=== Jira Integration Server: CE_jira ===#
# [integration_id=8]
SS_integration_dns = "http://ec2-54-243-9-157.compute-1.amazonaws.com:9090"
SS_integration_username = "brpm"
SS_integration_password = "-private-"
SS_integration_details = ""
SS_integration_password_enc ="__SS__Cj00V010UldRajFtWQ=="
#=== End ===#


#---------------------- Declarations -----------------------#
params["direct_execute"] = true #Set for local execution
require "#{FRAMEWORK_DIR}/brpm_framework"
rpm_load_module("ticket")

#---------------------- Methods ----------------------------#

#---------------------- Variables --------------------------#
issue_ids = @p.get("issue_id").split(",")
issue_ids = [@p.get("jira_issue_id")] if issue_ids[0] == ""
issue_ids = @p.tickets_foreign_ids.split(",").map{|l| l.strip } if issue_ids[0] == ""
comment = "RLM Request #{@p.request_id} - Step: #{@p.step.name} \nDeployed #{@p.SS_application} => #{@p.SS_environment} on #{@rpm.precision_timestamp}"
comment += "\n#{@p.comment}" unless @p.comment == ""
target_state = @p.desired_state

#---------------------- Main Body --------------------------#
# Check if we have been passed a package id from a promotion
@jira = Jira::Client.new(SS_integration_username, decrypt_string_with_prefix(SS_integration_password_enc), SS_integration_dns)
@rpm.message_box "Retrieving issue(s): #{issue_ids.join(",")}"
cookie = @jira.login
issue_ids.each do |issue_id|
  issue = @jira.get_issue(issue_id)
  cur_state = issue["fields"]["status"]["name"]
  if target_state.length > 1
    success = (cur_state = target_state)
	  @rpm.log "Issue #{issue_id} - State: #{cur_state}, should be #{target_state} - #{success}"
    unless success
      raise "Issue status is not ok to proceed"
    end
  end
  @rpm.log "Issue Information:\n#{issue.inspect}"
end


