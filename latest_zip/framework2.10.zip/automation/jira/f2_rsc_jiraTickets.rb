#---------------------- Jira: Get Issues -----------------------#
#    Queries for issues in Jira by filter or keyword
###
# project_key:
#   name: Jira key for project
#   position: A1:C1
#   type: in-text
#   required: no
# jql_query1:
#   name: query string 
#   position: A2:C2
#   type: in-text
#   required: yes
# jql_query2:
#   name: query string
#   position: A3:C3
#   type: in-text
#   required: no
# jql_query3:
#   name: query string
#   position: A4:C4
#   type: in-text
#   required: no
# jql_query4:
#   name: query string
#   position: A5:C5
#   type: in-text
#   required: no
###
#---------------------- Integration Header (do not modify) -----------------------#


#=== Jira Integration Server: CE_jira ===#
# [integration_id=8]
SS_integration_dns = "http://brpm.pulsar-it.be:9090/secure/Dashboard.jspa"
SS_integration_username = "niek"
SS_integration_password = "-private-"
SS_integration_details = ""
SS_integration_password_enc = "__SS__Cj09Z04zZ1RPNU5XYQ=="
#=== End ===#
@ss_integration_id = 8
#---------------------- Declarations -----------------------#
# Flag the script for direct execution
@script_name_handle = "jira_tickets"
body = File.open(File.join(FRAMEWORK_DIR,"lib","resource_framework.rb")).read
result = eval(body)
require File.join(FRAMEWORK_DIR,"lib","brpm_automation")
require File.join(FRAMEWORK_DIR,"lib","ticket")

#---------------------- Methods -----------------------#
def format_tickets(tickets, ticket_type = "none")
  results = []
  tickets["issues"].each do |item|
    log_it "Processing: #{item["key"]}"
		ticket = {}
		ticket["foreign_id"] = item["key"]
		ticket["name"] = item["fields"]["summary"]
		ticket["status"] = item["fields"]["status"]["name"]
		ticket["project_server_id"] = @ss_integration_id
		ticket["ticket_type"] = ticket_type 
		ticket["url"] = item["self"]
		ticket["extended_attributes"] = "Owner=#{item["fields"]["creator"]["name"]}"
    results << ticket
	end
  results
end

#---------------------- Variables -----------------------#
# Assign local variables to properties and script arguments
#params['jql_query1'] = "reporter='Bradford Byrd'"
#params['jql_query2'] = "summary~'Deploy'"
#params['jql_query3'] = ""
#params['jql_query4'] = ""
#params['project_key'] = "TST"
params['target_status'] = "Resolved"


#---------------------- Main Body -----------------------#
# make a connection to the Jira instance
def execute(script_params, parent_id, offset, max_records)
  log_it script_params.inspect
  @jira_pwd = decrypt_string_with_prefix(SS_integration_password_enc)
  @jira = Jira::JiraClient.new(SS_integration_username, @jira_pwd, SS_integration_dns)
  @jira.login
  project_key = script_params["project_key"]
  jql_query = "project = #{project_key}"
  jql_query = "#{jql_query} AND #{script_params['jql_query1']}"
  jql_query = "#{jql_query} AND #{script_params['jql_query2']}" if script_params.has_key?('jql_query2') && script_params['jql_query2'].length > 1
  jql_query = "#{jql_query} AND #{script_params['jql_query3']}" if script_params.has_key?('jql_query3') && script_params['jql_query3'].length > 1
  jql_query = "#{jql_query} AND #{script_params['jql_query4']}" if script_params.has_key?('jql_query4') && script_params['jql_query4'].length > 1
  log_it "Query criteria: #{jql_query}"
  raw_result = @jira.search(jql_query)
  log_it "Jira Result: #{raw_result.inspect}"
  unless raw_result.has_key?("issues") && !raw_result["issues"].empty?
    log_it "Jira query returned no issues"
    return {}
  end
  tickets = format_tickets(raw_result, "Jira")
  
  ############################ TICKET MAPPING AREA -- REQUIRED FOR MAPS_TO TICKET RESOURCE AUTOMATON 

  # we are going to expect an array here that fits the table control standard AND that can be mapped
  # to our ticket and extended attributes tabs.  For example, we must return an initial header element
  # and then data to match.  The unique id for the first column will not be shown on the table and 
  # is user to store selected values by check box on the table control. The foreign_id in the 2nd column
  # is often but not necessarily the same value as the ra_uniq_identifier since it is usually guaranteed to 
  # be unique by the remote ticketing system. 
  results = []
  # add the mandatory header row
  results << ["ra_uniq_identifier","Foreign Id","Name","Ticket Type", "Status", "URL", "Extended Attributes"]
  # now loop through the results and prepare a hash that fits the maps_to Ticket requirements
  if tickets.size > 0
    tickets.each_with_index do |ticket, index|
      log_it "Formatting: #{ticket["foreign_id"] }"
      #initialize a row array, not a hash, compatible with tickets and the table control
      #note: order is essential here as these are not key value pairs, must match header order
      t_row = []
      # find and set the unique identifier for this row -- string or integer
      # might be ok to put in the row index if this is blank or non-unique
      t_row << ticket["foreign_id"] || index
      # now set the ticket mapping fields required to turn this into a ticket model
      t_row <<  ticket["foreign_id"] || "Foreign ID Missing: Using #{Time.now.to_s}"
      t_row << (ticket["name"] || "Name Unavailable")[0..255]
      t_row << ticket["ticket_type"]
      t_row << (ticket["status"] || "Status Unavailable")[0..255]
      t_row << (ticket["url"] || "")[0..255]
      t_row << {"description" => ticket["extended_attributes"]}.to_json
      results << t_row
    end
  else
    # return just the headers and no subsequent values and rely on the control to say nothing was returned
  end


  # TODO: The AO adapter was not originally enabled to return total matching records and paginated results
  # so we are setting these values to the length of the returned records for compatibility
  paginated_results = { :perPage => tickets.length, 
                        :totalItems => tickets.length, 
                        :data => results }

  ############################ END TICKET MAPPING AREA #############################################

  # write the ticket data to the output file for record keeping and debugging
  write_to("#=== TICKET DATA ===#")
  write_to(paginated_results.to_yaml)
  write_to("#=== END TICKET DATA ===#")
  return paginated_results
end

def import_script_parameters
  { "render_as" => "Ticket" }
end
