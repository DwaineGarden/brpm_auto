#---------------------- Rally Update Defect -----------------------#
#    Updates defect tickets assigned to a step in a plan
#
#---------------------- Arguments ---------------------------#
###
# Defect Note:
#   name: Extra note text to add to ticket 
#   type: in-text
#   position: A1:F1
###

#=== General Integration Server: DevOps_Rally ===#
# [integration_id=2]
SS_integration_dns = "https://rally1.rallydev.com/slm"
SS_integration_username = "bbyrd@bmc.com"
SS_integration_password = "-private-"
SS_integration_details = "api_version: v2.0
workspace: ESM
project: RPM Sustaining"
SS_integration_password_enc = "__SS__Cj1Jek1QTjBaTkYyUQ=="
#=== End ===#

#---------------------- Declarations -----------------------#
params["direct_execute"] = true #Set for local execution
require "#{FRAMEWORK_DIR}/brpm_framework"

#---------------------- Methods ----------------------------#
def rally_rest_call(rally_url, method = "get", options = {})
  details = YAML.load(SS_integration_details)
  rally_url = "#{SS_integration_dns}/slm/webservice/#{details["api_version"]}/#{rally_url}" unless rally_url.start_with?("http")
  rest_params = { "headers" => {:accept => :json, :content_type => "text/plain"}, "username" => SS_integration_username, "password" => @int_password }
  rest_params["headers"][:cookies] = @rally_cookie if defined?(@rally_cookie)
  rest_params["data"] = options["data"] if options.has_key?("data")
  rest_params["verbose"] = true if options.has_key?("verbose")
  @rpm.log "Querying: #{rally_url}"
  result = @rpm.rest_call(URI.encode(rally_url), method, rest_params)
  result["data"]
end

def rally_api_token(regenerate = false)
  return @rally_api_token if defined?(@rally_api_token) and !regenerate
  details = YAML.load(SS_integration_details)
  url = "#{SS_integration_dns}/slm/webservice/#{details["api_version"]}/security/authorize"
  rest_params = { :headers => {:accept => :json}, :user => SS_integration_username, :password => "Tahoe4me", verify_ssl: OpenSSL::SSL::VERIFY_NONE}  
  result = RestClient::Resource.new(URI.escape(url), rest_params).get
  parsed_result = JSON.parse(result)
  @rally_api_token = parsed_result["OperationResult"]["SecurityToken"]
  @rally_cookie = result.cookies
  @rally_api_token
end

def build_query(query_hash)
  #query=(((Project.name = "BMC Release Process Management") and (Iteration.Name = "RPM iteration 28")) and (ScheduleState = "In-Progress"))
  #query=((Project.name = "BMC Release Process Management") and (ScheduleState = "In-Progress"))
  res = "("
  first = true
  query_hash.each do |k,v|
    res += "(" if query_hash.size > 2 and first
    res += "(#{k} = \"#{v}\")" if first
    res += " and (#{k} = \"#{v}\"))" unless first
    first = false
  end
  res
end
  
def rally_create_defect(defect_fields = {})
  api_token = rally_api_token
  if defect_fields.empty?
    @rpm.log "Must have field values to create defect"
    exit 1
  end
  defect_url = "defect/create?key=#{api_token}" if defect_url.nil?
end  

def rally_update_defect(defect_url, defect_fields = {})
  stamp = "#{Time.now.strftime("%H:%M:%S")}:"
  defect_fields["Description"] = "" if defect_fields["Description"].nil?
  new_note = "\n#{stamp} RLM - Deployed by request #{@p.request_id} - #{@p.SS_application} => #{@p.SS_environment}"
  defect_fields["Description"] += new_note 
  defect_url += "?key=#{rally_api_token}"
  defect_result = rally_rest_call(defect_url, "get", {"verbose" => true})
  description = defect_result["Defect"]["Description"]
  defect_data = {"Description" => "#{description}<p>#{defect_fields["Description"].gsub("\n","<p>")}"}
  update_result = rally_rest_call(defect_url, "post", {"data" => {"Defect" => defect_data}, "verbose" => true})
end

def rally_iterations(ticket_type = "defect")
  project = details["project"]
  query = "query=(Project.Name = \"#{project}\")"
  full_url = "iteration.js?#{query}&pagesize=200&fetch=true"
  response = rally_rest_call(full_url, "get")
end

#---------------------- Variables --------------------------#
details = YAML.load(SS_integration_details)
@int_password = decrypt_string_with_prefix(SS_integration_password_enc)
defect_note = @p.get("Defect Note")

#---------------------- Main -------------------------------#
# 
@rpm.message_box "Updating Rally Tickets", "title"
@rpm.log "\tTickets: #{@p.ticket_ids}"
@p.ticket_ids.split(",").map{|l| l.strip }.each do |ticket_id|
  @rpm.message_box "Updating: #{ticket_id}"
  result = @rest.get("tickets", ticket_id)
  defect_url = result["data"]["url"]
  @rpm.log "Defect URL: #{defect_url}"
  result = rally_update_defect(defect_url, {"Description" => defect_note})
  @rpm.log result.inspect
end

