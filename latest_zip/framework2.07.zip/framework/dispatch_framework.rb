# = BRPM Automation Framework - Dispatcher Edition
#    BMC Software - BJB 12-3-15
# ==== A collection of classes to simplify building BRPM automation
# === Instructions
# In your BRPM automation include a block like this to pull in the library
# <tt> params["direct_execute"] = true #Set for local execution
# <tt> require @params["SS_automation_results_dir"].gsub("automation_results","persist/automation_lib/brpm_framework.rb")
require 'popen4'
require 'timeout'
require 'erb'
@framework_dir = File.dirname(File.dirname(__FILE__))

def enhance_params(params)
  @p.local_params.each{|k,v| params[k] = v if v.is_a?(String) || v.is_a?(Fixnum) }
  params
end

def process_script(script_path)
  conts = File.read(script_path)
  action_txt = ERB.new(conts).result(binding)
  File.open(script_path, "w+") do |fil|
    fil.puts action_txt
    fil.flush
  end
end
  
# == Initialization on Include
# Objects are set for most of the classes on requiring the file
# these will be available in the BRPM automation
#  Customers should modify the BAA_BASE_PATH constant
# == Note the customer_include.rb reference.  To add your own routines and override methods use this file.
customer_include_file = File.join(@framework_dir, "customer_include.rb")
customer_include_file = File.join(CUSTOMER_LIB_DIR,"customer_include.rb") if defined?(CUSTOMER_LIB_DIR)
customer_include_file = File.join(File.dirname(@framework_dir.gsub("/BRPM/framework", "")), "customer_include.rb")
customer_include_file = File.join(@framework_dir,"customer_include_default.rb") if !File.exist?(customer_include_file)
conts = File.open(customer_include_file).read
eval conts # Use eval for resource automation to be dynamic

require "#{@framework_dir}/lib/brpm_automation"
@rpm = BrpmAutomation.new(@params)
@rpm.log "Loading customer include file: #{customer_include_file}"

@request_params = {} if not defined?(@request_params)
SS_output_file = @params["SS_output_file"]
require "#{@framework_dir}/lib/param"
@p = Param.new(@params, @request_params)
@request_params = @p.get_local_params
ARG_PREFIX = "ARG_" unless defined?(ARG_PREFIX)
