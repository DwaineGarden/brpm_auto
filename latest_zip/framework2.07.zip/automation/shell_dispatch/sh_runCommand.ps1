#![.ps1]powershell.exe -ExecutionPolicy Unrestricted -File

###
#
# COMMAND_TO_EXECUTE:
#   name: Source file path containing text to append
#   position: A1:F1
#   type: in-text
#
# TARGET_PATH:
#   name: Target file path to append to
#   position: A2:F2
#   type: in-text
#
###

#
# ExecuteCommand
#
#	Executes COMMAND_TO_EXECUTE in TARGET_PATH using dos batch
# 
$script:ErrorActionPreference = "Continue"

function convert_nsh_path($nsh_path){
  $reg = [regex]"^\/[A-Z]\/"
  $result = $nsh_path
  if($nsh_path -Match $reg ) {
    $ans = $reg.Match($nsh_path)
	$let = $ans.Captures[0].value.Replace("/","")
	$result = $nsh_path.Replace($ans.Captures[0].value, $let + ":\").Replace("/","\")
  }
  return $result;
}

$target = convert_nsh_path($env:TARGET_PATH)

$command_to_execute = $env:COMMAND_TO_EXECUTE
Write-host "Executing $command_to_execute"
if ($target) {
  cd $target;
 }
$command_to_execute

