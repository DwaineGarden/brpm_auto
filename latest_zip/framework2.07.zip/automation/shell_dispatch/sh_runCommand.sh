#![.sh]/bin/bash

###
#
# COMMAND_TO_EXECUTE:
#   name: Source file path containing text to append
#   position: A1:F1
#   type: in-text
#
# TARGET_PATH:
#   name: Target file path to append to
#   position: A2:F2
#   type: in-text
#
###

#
# ExecuteCommand
#
#	Executes COMMAND_TO_EXECUTE in TARGET_PATH using dos batch
# 


echo "Executing $COMMAND_TO_EXECUTE"
if [[ $RESULT -ne "" ]]
then
  cd $TARGET_PATH
fi
$COMMAND_TO_EXECUTE

